﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Threading;
using Sys = Cosmos.System;
using System.Net;
using System.Net.NetworkInformation;
using System.Diagnostics;
using System.IO;
using System.Xml.Linq;
using System.Text.RegularExpressions;
using System.Net.Http;
using System.Runtime.InteropServices;


namespace WDC_DOS_1._0_bete
{
    public class Kernel : Sys.Kernel
    {
        protected void Shutdown()
        {
            Console.WriteLine("Press any key to exit...");
            Thread.Sleep(1);
            Console.ReadKey();
            Environment.Exit(0);
        }
        protected override void BeforeRun()
        {

            Console.Clear();
            Thread.Sleep(2);
            Console.WriteLine("#------------------------------------------------------------------------------#");
            Thread.Sleep(1);
            Console.WriteLine("|WDC-DOS                                                                       |");
            Thread.Sleep(1);
            Console.WriteLine("|Writer:WuDiCC                                                                 |");
            Thread.Sleep(1);
            Console.WriteLine("|Version: 1.0 bete                                                             |");
            Thread.Sleep(1);
            Console.WriteLine("|3412199940                                                                    |");
            Thread.Sleep(1);
            Console.WriteLine("#------------------------------------------------------------------------------#");

            Thread.Sleep(1);

            Console.WriteLine("|Opening System......");

            Thread.Sleep(2);

            Console.WriteLine("#------------------------------------------------------------------------------#");

            Thread.Sleep(1);

            LoginUserName();
        }

        protected void consoleclr()
        {

        }

        protected void beforerunrun()
        {
            Thread.Sleep(2);
            Console.WriteLine("#------------------------------------------------------------------------------#");
            Thread.Sleep(1);
            Console.WriteLine("|WDC-DOS                                                                       |");
            Thread.Sleep(1);
            Console.WriteLine("|Writer:WuDiCC                                                                 |");
            Thread.Sleep(1);
            Console.WriteLine("|Version: 1.0 bete                                                             |");
            Thread.Sleep(1);
            Console.WriteLine("|3412199940                                                                    |");
            Thread.Sleep(1);
            Console.WriteLine("#------------------------------------------------------------------------------#");
            Run();
        }
        protected void LoginUserName()
        {
            Console.WriteLine("The account number of the public account is 'admin'");
            Console.Write("User name:");
            var Username = Console.ReadLine();
            if (Username != "admin")
            {
                Console.WriteLine("Username is error");
                Thread.Sleep(10);
                Console.WriteLine("Please try again");
                Thread.Sleep(10);
                LoginUserName();
            }
            else
            {
                LginPassword();
                Console.WriteLine("Enter 'help' to get help");
            }
        }

        protected void LginPassword()
        {
            Console.WriteLine("The password for the public account is '123456'");
            Console.Write("Password:");
            var Password = Console.ReadLine();
            if (Password != "123456")
            {
                Console.WriteLine("Password is error");
                Thread.Sleep(10);
                Console.WriteLine("Please try again");
                Thread.Sleep(10);
                LginPassword();
            }
            else
            {
                Thread.Sleep(10);
                Console.WriteLine("Welcome to WDC-DOS");
                Thread.Sleep(10);
                Thread.Sleep(2);
                Console.WriteLine("#------------------------------------------------------------------------------#");
                Run();
            }
        }

        protected void Setting()
        {
            Console.WriteLine("#------------------------------------------------------------------------------#");
            Thread.Sleep(100);
            Console.WriteLine("Enter 'setting help' to get help");
            while (true)
            {
                Console.Write("command:");
                string settinginput = Console.ReadLine();

                if (settinginput == "back")
                {
                    Console.WriteLine("#------------------------------------------------------------------------------#");
                    Thread.Sleep(100);
                    beforerunrun();
                }

                if (settinginput == "IP")
                {

                }

                if (settinginput == "setting help")
                {
                    Console.WriteLine("|1.'IP'--------------------------To get the IP");
                    Thread.Sleep(1);
                    Console.WriteLine("|2.'color'--------------------------Change console color");
                }

                if (settinginput == "color")
                {
                    Colorchange();
                }
            }
        }
        protected void Colorchange()
        {
            Console.Write("What's the color");
            Console.WriteLine(":");
            Console.WriteLine("|1.white");
            Console.WriteLine("|2.green");
            Console.WriteLine("|3.red");
            Console.WriteLine("|4.yellow");
            Console.WriteLine("|5.magenta");
            var color = Console.ReadLine();
            if (color == "1")
            {
                Console.ForegroundColor = ConsoleColor.White;
                Setting();
            }
            else
            {
                if (color == "2")
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Setting();
                }

                else
                {
                    if (color == "3")
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Setting();
                    }
                    else
                    {
                        if (color == "4")
                        {
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            Setting();
                        }
                        else
                        {
                            if (color == "5")
                            {
                                Console.ForegroundColor = ConsoleColor.Magenta;
                                Setting();
                            }
                            else
                            {
                                Console.WriteLine("Commandn is error,please try again");
                                Thread.Sleep(100);
                                Colorchange();
                            }
                        }
                    }
                }
            }
        }

        protected override void Run()
        {
            while (true)
            {

                Console.Write(">>> ");
                var input = Console.ReadLine();
                Console.Write("Command: ");
                Console.WriteLine(input);

                if (input == "help")
                {
                    Console.WriteLine("|1.'help program'--------------------------Help for the Program");
                    Thread.Sleep(1);
                    Console.WriteLine("|2.'help command'--------------------------Help for the Command ");
                    Thread.Sleep(1);
                    Console.WriteLine("|3.'help game'--------------------------Help for the Game ");


                }

                if (input == "help program")
                {
                    Console.WriteLine("|1.'open setting'--------------------------open setting program ");
                    Thread.Sleep(1);
                    Console.WriteLine("|2.'open files'--------------------------open file transferr");
                    Thread.Sleep(1);

                }

                if (input == "help game")
                {
                    Console.WriteLine("|1.'Minecraft'");
                    Thread.Sleep(1);
                }

                if (input == "help game")
                {

                }

                if (input == "open setting")
                {
                    Setting();
                }

                if (input == "help command")
                {
                    Console.WriteLine("|1.'reboot'--------------------------restart the computer ");
                    Thread.Sleep(1);
                    Console.WriteLine("|2.'shutdown:'--------------------------shutdown");
                    Console.WriteLine("|3.'console clr'--------------------------clear console ");
                    Thread.Sleep(1);
                    Console.WriteLine("|4.'get'--------------------------from html get files");
                    Thread.Sleep(1);
                    Console.WriteLine("|5.'console print:'--------------------------console say ");
                    Thread.Sleep(1);
                    Thread.Sleep(1);
                }

                if (input == "shutdown")
                {
                    Console.WriteLine("Shutting down......");
                    Thread.Sleep(1000);
                    Shutdown();
                }

                if (input == "reboot")
                {
                    Console.WriteLine("Restarting the computer......");
                    Thread.Sleep(10);
                    Console.Clear();
                    Thread.Sleep(500);
                    BeforeRun();
                }

                if (input == "get")
                {

                }

                if (input == "console clr")
                {

                    Console.Clear();

                    Thread.Sleep(1);

                    Console.WriteLine("#------------------------------------------------------------------------------#");
                    Thread.Sleep(1);
                    Console.WriteLine("|System bete 1                                                                 |");
                    Thread.Sleep(1);
                    Console.WriteLine("|Writer:WuDiCC                                                                 |");
                    Thread.Sleep(1);
                    Console.WriteLine("#------------------------------------------------------------------------------#");

                    Thread.Sleep(1);

                    Console.WriteLine("|Welcome to System bete 1");

                    Thread.Sleep(2);

                    Console.WriteLine("|Enter 'help' for help");

                    Thread.Sleep(2);

                    Console.WriteLine("#------------------------------------------------------------------------------#");

                    Thread.Sleep(1);


                }
            }
        }
    }
}
